<?php

return [

	'list_customers'	=> 'List Customers',
	'new_customer' 		=> 'New Customer',
	'customer_id'		=> 'Customer ID',
	'name' 				=> 'Name',
	'email' 			=> 'Email',
	'phone_number' 		=> 'Phone Number',
	'avatar' 			=> 'Avatar',
	'choose_avatar'		=> 'Choose Avatar',
	'address'			=> 'Address',
	'city'				=> 'City',
	'state'				=> 'State',
	'zip'				=> 'Zip',
	'company_name'		=> 'Company Name',
	'account'			=> 'Account',
	'submit'			=> 'Submit',
	'edit'	=> 'Edit',
	'delete'	=> 'Delete',
	'update_customer' => 'Update Customer',

];
