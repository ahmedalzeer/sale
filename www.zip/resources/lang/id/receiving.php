<?php

return [

	'item_receiving' => 'Penerimaan Barang',
	'search_item' => 'Cari Barang:',
	'invoice' => 'Faktur',
	'employee' => 'Pegawai',
	'payment_type' => 'Jenis Pembayaran',
	'supplier' => 'Pemasok',
	'item_id' => 'ID Barang',
	'item_name' => 'Nama Barang',
	'cost' => 'Harga Beli',
	'quantity' => 'Quantity',
	'total' => 'Total',
	'amount_tendered' => 'Jumlah Pembayaran',
	'comments' => 'Komentar',
	'grand_total' => 'TOTAL:',
	'submit' => 'Selesaikan Penerimaan',
	//struk
	'receiving_id' => 'ID Penerimaan',
	'item' => 'Barang',
	'price' => 'Harga',
	'qty' => 'Qty',
	'print' => 'Cetak',
	'new_receiving' => 'Penerimaan Baru',

];
