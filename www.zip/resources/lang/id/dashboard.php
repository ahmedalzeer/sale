<?php

return [

	'welcome' => 'Selamat Datang di TutaPOS - TUTA Point of Sale.',
	'statistics' 		=> 'Statistik',
	'total_employees' 	=> 'Total Pegawai',
	'total_customers' 	=> 'Total Pelanggan',
	'total_suppliers' 	=> 'Total Supplier',
	'total_items' 		=> 'Total Barang',
	'total_item_kits' 	=> 'Total Barang Paket',
	'total_receivings' 	=> 'Total Penerimaan',
	'total_sales' 		=> 'Total Penjualan',

];
