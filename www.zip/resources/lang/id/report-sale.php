<?php

return [

	'reports' => 'Laporan',
	'sales_report' => 'Laporan Penjualan',
	'grand_total' => 'TOTAL',
	'grand_profit' => 'KEUNTUNGAN',
	'sale_id' => 'ID Penjualan',
	'date' => 'Tanggal',
	'items_purchased' => 'Barang yang dibeli',
	'sold_by' => 'Dijual Oleh',
	'sold_to' => 'Dijual Kepada',
	'total' => 'Total',
	'profit' => 'Keuntungan',
	'payment_type' => 'Jenis Pembayaran',
	'comments' => 'Komentar',
	'detail' => 'Rincian',
	'item_id' => 'ID Barang',
	'item_name' => 'Nama Barang',
	'quantity_purchase' => 'Jumlah yang dibeli',

];
