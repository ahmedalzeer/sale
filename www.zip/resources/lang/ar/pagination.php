<?php

return [


    'previous' => 'السابقة',
    'next'     => 'التالية',

];