<?php

return [

    'list_customers'	=> 'قائمة العملاء',
    'new_customer' 		=> 'عميل جديد',
    'customer_id'		=> 'م العميل',
    'name' 				=> 'الاسم',
    'email' 			=> 'الايميل',
    'phone_number' 		=> 'رقم التليفون',
    'avatar' 			=> 'صورة رمزية',
    'choose_avatar'		=> 'اختار الصورة رمزية',
    'address'			=> 'العنوان',
    'city'				=> 'المدينة',
    'state'				=> 'المحافظة',
    'zip'				=> 'الرقم البريدي',
    'company_name'		=> 'اسم الشركة',
    'account'			=> 'الحساب',
    'submit'			=> 'حفظ',
    'edit'	=> 'تعديل',
    'delete'	=> 'حذف',
    'update_customer' => 'تحديث بيانات عميل',

];
