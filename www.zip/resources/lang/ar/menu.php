<?php

return [

    'dashboard' 			=> 'الرئيسية',
    'customers' 			=> 'العملاء',
    'employees'				=> 'الموظفون',
    'items' 				=> 'الاصناف',
    'item_kits' 			=> 'الاقسام',
    'suppliers' 			=> 'الموردين',
    'receivings' 			=> 'المشتروات',
    'sales' 				=> 'المبيعات',
    'reports' 				=> 'التقارير',
    'receivings_report' 	=> 'تقرير المستلمات',
    'sales_report' 			=> 'تقرير المبيعات',
    'logout'				=> 'خروج',
    'application_settings' 	=> 'اعدادات البرنامج'

];
