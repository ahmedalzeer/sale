<?php

return [

    'list_suppliers'	=> 'قائمة الموردين',
    'new_supplier'		=> 'مورد جديد',
    'company_name' 		=> 'اسم الشركة',
    'name' 	=> 'الاسم',
    'email' 	=> 'الايميل',
    'phone_number' => 'رقم التليفون',
    'avatar'		=> 'صورة رمزية',
    'choose_avatar' => 'اختار الصورة الرمزية:',
    'address' => 'العنوان',
    'city' => 'المدينة',
    'state' => 'المحافظة',
    'zip' => 'الرقم البريدي',
    'comments' => 'التعليقات',
    'account' => 'الكمية',
    'submit' => 'حفظ',
    'edit' => 'تعديل',
    'delete' => 'حذف',
    'update_supplier' => 'تحديث بيانات مورد',

];
