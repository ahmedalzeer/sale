<?php

return [

    'item_kits'	=> 'الاقسام',
    'new_item_kit'		=> 'اضافة قسم',
    'item_kit_id' 		=> 'م القسم',
    'item_kit_name' 	=> 'اسم القسم',
    'cost_price' 	=> 'سعر الجملة',
    'selling_price' => 'سعر البيع',
    'item_kit_description'		=> 'وصف القسم',
    'search_item' => 'البحث عن صنف',
    'description' => 'الوصف',
    'quantity' => 'الكمية',
    'profit' => 'الربح',
    'item_id' => 'م الصنف',
    'item_name' => 'اسم الصنف',
    'submit' => 'حفظ',


];