<?php

return [

    'welcome' 			=> 'مرحبا بك',
    'statistics' 		=> 'الاحصاءات',
    'total_employees' 	=> 'اجمالي الموطفون',
    'total_customers' 	=> 'اجمالي العملاء',
    'total_suppliers' 	=> 'اجمالي الموردين',
    'total_items' 		=> 'اجمالي الاصناف',
    'total_item_kits' 	=> 'اجمالي الاقسام',
    'total_receivings' 	=> 'اجمالي المشتروات',
    'total_sales' 		=> 'اجمالي المبيعات',

];