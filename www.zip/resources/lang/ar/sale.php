<?php

return [

    'sales_register' => 'تسجيل المبيعات',
    'search_item' => 'بحث عن صنف:',
    'invoice' => 'فاتورة',
    'employee' => 'الموظف',
    'payment_type' => 'طريقة الدفع',
    'customer' => 'العميل',
    'item_id' => 'م الصنف',
    'item_name' => 'اسم الصنف',
    'price' => 'السعر',
    'quantity' => 'الكمية',
    'total' => 'الاجمالي',
    'add_payment' => 'المدفوع',
    'comments' => 'التعليقات',
    'grand_total' => 'الاجمالي:',
    'amount_due' => 'المبلغ المستحق',
    'submit' => 'اتمام عملية البيع',
    //struk
    'sale_id' => 'م عملية البيع',
    'item' => 'الصنف',
    'price' => 'السعر',
    'qty' => 'الكمية',
    'print' => 'طباعة',
    'new_sale' => 'عملية بيع جديدة',

];
