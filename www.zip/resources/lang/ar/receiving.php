<?php

return [

    'item_receiving' => 'الاصناف المستلمة',
    'search_item' => 'بحث عن صنف:',
    'invoice' => 'فاتورة',
    'employee' => 'الموظف',
    'payment_type' => 'طريقة الدفع',
    'supplier' => 'المورد',
    'item_id' => 'م الصنف',
    'item_name' => 'اسم الصنف',
    'cost' => 'التكلفة',
    'quantity' => 'الكمية',
    'total' => 'الاجمالي',
    'amount_tendered' => 'المدفوع',
    'comments' => 'التعليقات',
    'grand_total' => 'الاجمالي:',
    'submit' => 'حفظ المستلمات',
    //struk
    'receiving_id' => 'م المستلمات',
    'item' => 'الصنف',
    'price' => 'السعر',
    'qty' => 'الكمية',
    'print' => 'طباعة',
    'new_receiving' => 'عملية مستلمات جديدة',

];
