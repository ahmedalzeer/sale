<?php

return [

    'reports' => 'التقارير',
    'receivings_report' => 'تقرير المستلمات',
    'grand_total' => 'الاجمالي',
    'receiving_id' => 'م',
    'date' => 'البيانات',
    'items_received' => 'الاصناف المستلمة',
    'received_by' => 'استلمت بواسطة',
    'supplied_by' => 'وردت من المورد:',
    'total' => 'الاجمالي',
    'payment_type' => 'طريقة الدفع',
    'comments' => 'التعليقات',
    'detail' => 'التفاصيل',
    'item_id' => 'م',
    'item_name' => 'اسم الصنف',
    'item_received' => 'الصنف المستلم',

];
