<?php

return [

    'list_employees' => 'قائمة الموظفون',
    'new_employee' => 'اضافة موظف',
    'person_id' => 'م الموظف',
    'name' => 'الاسم',
    'employee.email' => 'الايميل',
    'username' => 'اسم المستخدم',
    'password' => 'الباسورد',
    'confirm_password' => 'تاكيد الباسورد',
    'submit' => 'حفظ',
    'edit' => 'تعديل',
    'delete' => 'حذف',
    'update_employee' => 'تحديث بيانات موظف'

];