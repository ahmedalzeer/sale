<?php

return [

    'reports' => 'التقارير',
    'sales_report' => 'تقارير المبيعات',
    'grand_total' => 'الاجمالي',
    'grand_profit' => 'الربح',
    'sale_id' => 'م البيع',
    'date' => 'البيانات',
    'items_purchased' => 'الاصناف المباعة',
    'sold_by' => 'بيعت بواسطة',
    'sold_to' => 'بيعت الي',
    'total' => 'الاجمالي',
    'profit' => 'الربح',
    'payment_type' => 'طريقة الدفع',
    'comments' => 'التعليقات',
    'detail' => 'التفاصيل',
    'item_id' => 'م الصنف',
    'item_name' => 'اسم الصنف',
    'quantity_purchase' => 'الكمية المباعة',

];
